import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.startsWith('http') 
  ? process.env.NEXT_PUBLIC_SUPABASE_URL 
  : 'https://placeholder.supabase.co'

const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.length > 20
  ? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY 
  : 'placeholder'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)


