import { MenuItem } from "@/types";

export const menuItems: MenuItem[] = [
  {
    id: "1",
    name: "Oat Milk Lavender Latte",
    description: "Our signature espresso pulled over steamed oat milk and house-made lavender syrup.",
    price: 6.50,
    category: "Signatures",
    imageUrl: "https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=1000&auto=format&fit=crop",
    dietaryTags: ["Vegan", "Dairy-Free"],
    roastLevel: "Medium"
  },
  {
    id: "2",
    name: "Ethiopian Yirgacheffe Pour Over",
    description: "Bright and floral with notes of jasmine, bergamot, and blueberry.",
    price: 5.50,
    category: "Pour Over",
    imageUrl: "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=1000&auto=format&fit=crop",
    dietaryTags: ["Vegan"],
    roastLevel: "Light"
  },
  {
    id: "3",
    name: "Double Espresso",
    description: "A perfectly extracted double shot of our seasonal Auroma reserve blend.",
    price: 3.50,
    category: "Espresso Bar",
    imageUrl: "https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?q=80&w=1000&auto=format&fit=crop",
    dietaryTags: ["Vegan"],
    roastLevel: "Dark"
  },
  {
    id: "4",
    name: "Almond Croissant",
    description: "Twice-baked butter croissant filled with sweet almond frangipane.",
    price: 4.75,
    category: "Pastries",
    imageUrl: "https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=800&auto=format&fit=crop",
    dietaryTags: ["Vegetarian"],
  },
  {
    id: "5",
    name: "Caramel Macchiato",
    description: "Layered espresso with steamed milk and a rich caramel drizzle topping.",
    price: 5.25,
    category: "Espresso Bar",
    imageUrl: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?q=80&w=1000&auto=format&fit=crop",
    dietaryTags: [],
    roastLevel: "Medium"
  },
  {
    id: "6",
    name: "Cold Brew Vanilla",
    description: "Our signature 24-hour steep cold brew infused with organic vanilla syrup.",
    price: 5.00,
    category: "Signatures",
    imageUrl: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?q=80&w=1000&auto=format&fit=crop",
    dietaryTags: ["Vegan", "Dairy-Free"],
    roastLevel: "Medium"
  },
  {
    id: "7",
    name: "Matcha Espresso Fusion",
    description: "A visually stunning layer of earthy matcha and cold milk with a float of espresso.",
    price: 6.00,
    category: "Signatures",
    imageUrl: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?q=80&w=800&auto=format&fit=crop",
    dietaryTags: ["Vegetarian"],
    roastLevel: "Medium"
  }
];
